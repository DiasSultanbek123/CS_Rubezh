
var1 = 'Переменная 1'
var2 = 'Переменная 2'
var3 = 'Переменная 3'


def function1(a, b):
    return a + b


def function2(a, b):
    return a**b


def function3(a, b, c):
    return (a+b)**c
