<?php
$con = mysqli_connect('localhost', 'root', 'root', 'task');
if (!$con) {
    die('База данных(');
}
